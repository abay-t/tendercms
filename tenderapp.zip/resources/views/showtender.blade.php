@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-9">
            <div class="card">
                <div class="table-title">
                    <div class="row">
                        <div class="col-sm-5">
                            <a href="{{url('admin/tenders')}}" class="btn btn-success">
                                <i class="fas fa-file-contract"></i> <span>Тендеры</span>
                            </a>
                        </div>
                        <div class="col-sm-7">
                            <a href="{{ route('addtender') }}" class="btn btn-primary"><i class="material-icons"></i> <span>Добавить тендер</span></a>
                            <!-- <a href="#" class="btn btn-primary"><i class="material-icons"></i> <span>Export to Excel</span></a> -->                       
                        </div>
                    </div>
                </div>
                <h2 style="padding: 15px;">{{ __('Данные о тендере') }}</h2>
                <br>
                @if(session()->has('message'))
                <div class="alert alert-success">
                    {{ session()->get('message') }}
                </div>
                @endif
                   

                        <div class="form-group row">
                            <label for="portal" class="col-md-4 col-form-label text-md-right">{{ __('Портал закупки') }}</label>

                            <div class="col-md-6">
                                {{$tender->portal}}

                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="type" class="col-md-4 col-form-label text-md-right">{{ __('Тип закупки ') }}</label>

                            <div class="col-md-6">
                                {{$tender->type}}
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="predmet" class="col-md-4 col-form-label text-md-right">{{ __('Предмет закупки') }}</label>

                            <div class="col-md-6">
                                {{$tender->predmet}}
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password-confirm" class="col-md-4 col-form-label text-md-right">{{ __('Номер закупки') }}</label>

                            <div class="col-md-6">
                                {{$tender->no}}
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="link" class="col-md-4 col-form-label text-md-right">{{ __('Ссылка на закупку') }}</label>

                            <div class="col-md-6">
                                {{$tender->link}}
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="zakazchik" class="col-md-4 col-form-label text-md-right">{{ __('Заказчик') }}</label>

                            <div class="col-md-6">
                                {{$tender->zakazchik}}
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="title" class="col-md-4 col-form-label text-md-right">{{ __('Наименование закупки') }}</label>

                            <div class="col-md-6">
                                {{$tender->title}}
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="quantity" class="col-md-4 col-form-label text-md-right">{{ __('Количество (цифры)') }}</label>

                            <div class="col-md-6">
                                {{$tender->quantity}}
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="priceForUnit" class="col-md-4 col-form-label text-md-right">{{ __('Цена закупки за ед. (цифры)') }}</label>

                            <div class="col-md-6">
                                {{$tender->priceForUnit}}
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="sum" class="col-md-4 col-form-label text-md-right">{{ __('Сумма закупки (вычисляется автоматически)') }}</label>

                            <div class="col-md-6">
                                {{$tender->sum}}
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="finishTime" class="col-md-4 col-form-label text-md-right">{{ __('Срок окончания приема заявок') }}</label>

                            <div class="col-md-6">
                                {{$tender->finishTime}}
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="address" class="col-md-4 col-form-label text-md-right">{{ __('Адрес поставки') }}</label>

                            <div class="col-md-6">
                                {{$tender->address}}
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="finishForDelivery" class="col-md-4 col-form-label text-md-right">{{ __('Срок поставки (цифры)') }}</label>

                            <div class="col-md-6">
                                {{$tender->finishForDelivery}}
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="obespechenie" class="col-md-4 col-form-label text-md-right">{{ __('Обеспечение заявки') }}</label>

                            <div class="col-md-6">
                                <input class="form-check-input" type="checkbox" {{ $tender->obespechenie == "1" ? 'checked' : '' }} id="obespechenie" name="obespechenie">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="submitted" class="col-md-4 col-form-label text-md-right">{{ __('Заявка подано') }}</label>

                            <div class="col-md-6">
                                <input class="form-check-input" type="checkbox" {{ $tender->submitted == "1" ? 'checked' : '' }} id="submitted" name="submitted">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="providerUnitPrice" class="col-md-4 col-form-label text-md-right">{{ __('Цена поставщика за ед. (цифры)') }}</label>

                            <div class="col-md-6">
                                {{$tender->providerUnitPrice}}
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="providerSumPrice" class="col-md-4 col-form-label text-md-right">{{ __('Сумма поставщика (вычисляется автоматически)') }}</label>

                            <div class="col-md-6">
                                {{$tender->providerSumPrice}}
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="transportation" class="col-md-4 col-form-label text-md-right">{{ __('Транспортные расходы (цифры)') }}</label>

                            <div class="col-md-6">
                                {{$tender->transportation}}
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="customs" class="col-md-4 col-form-label text-md-right">{{ __('Растаможка (цифры)') }}</label>

                            <div class="col-md-6">
                                {{$tender->customs}}
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="certification" class="col-md-4 col-form-label text-md-right">{{ __('Сертификация (цифры)') }}</label>

                            <div class="col-md-6">
                                {{$tender->certification}}
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="allConsumptions" class="col-md-4 col-form-label text-md-right">{{ __('Общие расходы (вычисляется автоматически)') }}</label>

                            <div class="col-md-6">
                                {{$tender->allConsumptions}}
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="myUnitPrice" class="col-md-4 col-form-label text-md-right">{{ __('Моя цена за ед. (цифры)') }}</label>

                            <div class="col-md-6">
                                {{$tender->myUnitPrice}}
                            </div>
                        </div>
                         <div class="form-group row">
                            <label for="mySum" class="col-md-4 col-form-label text-md-right">{{ __('Моя сумма (вычисляется автоматически)') }}</label>

                            <div class="col-md-6">
                                {{$tender->mySum}}
                            </div>
                        </div>
                         <div class="form-group row">
                            <label for="taxProcent" class="col-md-4 col-form-label text-md-right">{{ __('Процент налогообложения Налог (вычисляется автоматически)') }}</label>

                            <div class="col-md-6">
                                {{$tender->taxProcent}}
                            </div>
                        </div>
                         <div class="form-group row">
                            <label for="profit" class="col-md-4 col-form-label text-md-right">{{ __('Прибыль (вычисляется автоматически)') }}</label>

                            <div class="col-md-6">
                                {{$tender->profit}}
                            </div>
                        </div>
                         <div class="form-group row">
                            <label for="margin" class="col-md-4 col-form-label text-md-right">{{ __('Маржа(%) (вычисляется автоматически)') }}</label>

                            <div class="col-md-6">
                                {{$tender->margin}}
                            </div>
                        </div>
                         <div class="form-group row">
                            <label for="sumNDS" class="col-md-4 col-form-label text-md-right">{{ __('Сумма НДС (вычисляется автоматически)') }}</label>

                            <div class="col-md-6">
                                {{$tender->sumNDS}}
                            </div>
                        </div>
                         <div class="form-group row">
                            <label for="comission" class="col-md-4 col-form-label text-md-right">{{ __('Комиссия банка за перевод и другие операции по тендеру (цифры)') }}</label>

                            <div class="col-md-6">
                                {{$tender->comission}}
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="tz" class="col-md-4 col-form-label text-md-right">{{ __('Техничечкое задание на закупку  ') }}</label>

                            <div class="col-md-6">
                                <a href="{{url(''.$tender->tz)}}" target="_blank">{{$tender->tz}}</a>
                                

                            </div>
                        </div>  

                        
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
