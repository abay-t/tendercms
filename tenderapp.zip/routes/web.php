<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

// Registration Routes...
Route::get('register', 'Auth\RegisterController@showRegistrationForm')->name('register')->middleware('admin');
Route::post('register', 'Auth\RegisterController@register')->middleware('admin');


// App Routes...

Route::get('/home', 'HomeController@index')->name('home');

//Admin routes

Route::get('/admin', 'AdminController@admin')->name('admin')->middleware('admin');
Route::get('/admin/users', 'AdminController@admin')->name('users')->middleware('admin');
Route::get('/admin/tenders', 'AdminController@tenders')->name('tenders')->middleware('admin');

//User routes

Route::get('/user/{id}/edit', 'AdminController@edituser');
Route::post('user/{id}/update', 'AdminController@updateuser')->name('edituser');
Route::get('user/{id}/delete', 'AdminController@deleteuser')->name('deleteuser');

// Tender routes
Route::get('addtender', 'TenderController@create')->name('addtender');
Route::post('addtender', 'TenderController@store')->name('storetender');
Route::get('tender/{id}', 'TenderController@show')->name('showtender');
Route::get('tender/{id}/edit', 'TenderController@edit');
Route::post('tender/{id}/update', 'TenderController@update')->name('edittender');
Route::get('tender/{id}/delete', 'TenderController@destroy')->name('deletetender');
