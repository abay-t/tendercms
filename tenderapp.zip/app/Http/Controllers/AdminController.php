<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use DB;

class AdminController extends Controller
{
     public function __construct()
    {
        $this->middleware('admin');
    }


    public function admin()
    {
    	$users = DB::table('users')->paginate(15);

        return view('admin.index', ['users' => $users]);
    }

    public function tenders(){
    	$tenders = DB::table('tenders')->paginate(15);
    	return view('admin.tenders', ['tenders' => $tenders]);
    }

    public function edituser($id){
    	$user = User::find($id);
    	return view('admin.edituser', ['user' => $user]);
    }

    public function updateuser($id){
    	$user = User::find($id);
    	$this->validate(request(), [
            'email' => 'unique:users,email,'.$user->id,
            'password' => 'confirmed'
        ]);

        $user->name = request('name');
        $user->email = request('email');
        if(request('password') != null)
        	$user->password = bcrypt(request('password'));
        $user->organization = request('organization');
        $user->bin = request('bin');
        $user->dolzhnost = request('dolzhnost');
        $user->address = request('address');
        $user->contact = request('contact');

        if (file_exists(request('rekvizit'))) {
            $file = request('rekvizit');
            $name = date("Y-m-d-H-i-s").request('rekvizit')->getClientOriginalName();
            
            $file->move(getcwd().'/public/uploads/user/', $name);
            $user->update(['rekvizit' => '/public/uploads/user/'.$name]);
        }
        if (file_exists(request('svidetelstvo'))) {
            $file = request('svidetelstvo');
            $name = date("Y-m-d-H-i-s").request('svidetelstvo')->getClientOriginalName();
            
            $file->move(getcwd().'/public/uploads/user/', $name);
            $user->update(['svidetelstvo' => '/public/uploads/user/'.$name]);
        }
        if (file_exists(request('nds'))) {
            $file = request('nds');
            $name = date("Y-m-d-H-i-s").request('nds')->getClientOriginalName();
            
            $file->move(getcwd().'/public/uploads/user/', $name);
            $user->update(['nds' => '/public/uploads/user/'.$name]);
        }
        if (file_exists(request('ustav'))) {
            $file = request('ustav');
            $name = date("Y-m-d-H-i-s").request('ustav')->getClientOriginalName();
            
            $file->move(getcwd().'/public/uploads/user/', $name);
            $user->update(['ustav' => '/public/uploads/user/'.$name]);
        }

        if (file_exists(request('prikaz'))) {
            $file = request('prikaz');
            $name = date("Y-m-d-H-i-s").request('prikaz')->getClientOriginalName();
            
            $file->move(getcwd().'/public/uploads/user/', $name);
            $user->update(['prikaz' => '/public/uploads/user/'.$name]);
        }

        if (file_exists(request('reshenie'))) {
            $file = request('reshenie');
            $name = date("Y-m-d-H-i-s").request('reshenie')->getClientOriginalName();
            
            $file->move(getcwd().'/public/uploads/user/', $name);
            $user->update(['reshenie' => '/public/uploads/user/'.$name]);
        }

        $user->save();
        return redirect()->back()->with('message', 'Ползователь обновлен');
    }

    public function deleteuser($id){
    	$user = User::find($id);    
		$user->delete();
		return redirect()->back()->with('message', 'Ползователь удален');
    }
}
