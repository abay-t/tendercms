<?php $__env->startSection('content'); ?>

<div class="container">
        <div class="table-wrapper">
            <div class="table-title">
                <div class="row">
                    <div class="col-sm-5">
						<a href="<?php echo e(url('admin/tenders')); ?>" class="btn btn-success">
							<i class="fas fa-file-contract"></i> <span>Тендеры</span>
						</a>
						<a href="<?php echo e(url('admin/users')); ?>" class="btn btn-success">
							<i class="fas fa-user"></i> <span>Пользователи</span>
						</a>
					</div>
					<div class="col-sm-7">
						<a href="<?php echo e(route('register')); ?>" class="btn btn-primary"><i class="material-icons"></i> <span>Добавить ползователя</span></a>						
					</div>
                </div>
            </div>
            <?php if(session()->has('message')): ?>
            <div class="alert alert-success">
            	<?php echo e(session()->get('message')); ?>

            </div>
            <?php endif; ?>
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>ФИО</th>						
						<th>Наименование организации</th>
						<th>Должность</th>
                        <th>Status</th>
						<th>Действие</th>
                    </tr>
                </thead>
                <tbody>
                	<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

	                	<tr>
	                		<td><?php echo e(++$key); ?></td>
	                		<td>
	                			<a href="#">
	                				<!-- <img src="<?php echo e(asset('/images/1.jpg')); ?>" class="avatar" alt="Avatar">  -->
	                			<?php echo e($user->name); ?>

	                			</a>
	                		</td>
	                		<td><?php echo e($user->organization); ?></td>                        
	                		<td><?php echo e($user->dolzhnost); ?></td>
	                		<td><span class="status text-success">•</span> Active</td>
	                		<td>
	                			<a href="<?php echo e(url('user/'.$user->id.'/edit')); ?>" class="settings" title="" data-toggle="tooltip" data-original-title="Settings"><i class="material-icons"></i></a>
	                			<?php if(Auth::user()->id != $user->id): ?>
	                			<a onclick="return confirm('Вы уверены?')" href="<?php echo e(url('user/'.$user->id.'/delete')); ?>"  class="delete" title="" data-original-title="Delete"><i class="material-icons"></i></a>
	                			<?php endif; ?>
	                		</td>
	                	</tr>
                	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
                </tbody>
            </table>

            <?php echo $__env->make('pagination', ['paginator' => $users], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tenderapp\resources\views/admin/index.blade.php ENDPATH**/ ?>