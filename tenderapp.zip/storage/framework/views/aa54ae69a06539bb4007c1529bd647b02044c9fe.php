<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-9">
            <div class="card">
                <div class="table-title">
                    <div class="row">
                        <div class="col-sm-5">
                            <a href="<?php echo e(url('admin/tenders')); ?>" class="btn btn-success">
                                <i class="fas fa-file-contract"></i> <span>Тендеры</span>
                            </a>
                            <a href="<?php echo e(url('admin/users')); ?>" class="btn btn-success">
                                <i class="fas fa-user"></i> <span>Пользователи</span>
                            </a>
                        </div>
                        <div class="col-sm-7">
                            <a href="<?php echo e(route('addtender')); ?>" class="btn btn-primary"><i class="material-icons"></i> <span>Добавить тендер</span></a>
                            <!-- <a href="#" class="btn btn-primary"><i class="material-icons"></i> <span>Export to Excel</span></a> -->                       
                        </div>
                    </div>
                </div>
                <h2 style="padding: 15px;"><?php echo e(__('Изменить тендера')); ?></h2>
                <br>
                <?php if(session()->has('message')): ?>
                <div class="alert alert-success">
                    <?php echo e(session()->get('message')); ?>

                </div>
                <?php endif; ?>
                    <form method="POST" action="<?php echo e(route('edittender', $tender->id)); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="portal" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Портал закупки')); ?></label>

                            <div class="col-md-6">
                                <select name="portal" class="custom-select">
                                  <option>Выберите портала</option>
                                  <option value="Гос. закупки" <?php echo e($tender->portal === "Гос. закупки" ? 'selected' : ''); ?>>Гос. закупки</option>
                                  <option value="Самурык" <?php echo e($tender->portal === "Самурык" ? 'selected' : ''); ?>>Самурык</option>
                                  <option value="Реестр" <?php echo e($tender->portal === "Реестр" ? 'selected' : ''); ?>>Реестр</option>
                                </select>

                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="type" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Тип закупки ')); ?></label>

                            <div class="col-md-6">
                                <select name="type" class="custom-select">
                                  <option>Выберите тип</option>
                                  <option value="Товар" <?php echo e($tender->type === "Товар" ? 'selected' : ''); ?>>Товар</option>
                                  <option value="Услуга" <?php echo e($tender->type === "Услуга" ? 'selected' : ''); ?>>Услуга</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="predmet" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Предмет закупки')); ?></label>

                            <div class="col-md-6">
                                <select name="predmet" class="custom-select">
                                  <option>Выберите предмет</option>
                                  <option value="Товар" <?php echo e($tender->predmet === "Товар" ? 'selected' : ''); ?>>Товар</option>
                                  <option value="2" <?php echo e($tender->predmet === "Предмет 2" ? 'selected' : ''); ?>>Предмет 2</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password-confirm" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Номер закупки')); ?></label>

                            <div class="col-md-6">
                                <input id="no" type="text" value="<?php echo e($tender->no); ?>" class="form-control" name="no" required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="link" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Ссылка на закупку')); ?></label>

                            <div class="col-md-6">
                                <input id="link" type="text" value="<?php echo e($tender->link); ?>" class="form-control" name="link" required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="zakazchik" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Заказчик')); ?></label>

                            <div class="col-md-6">
                                <input id="zakazchik" type="text" value="<?php echo e($tender->zakazchik); ?>" class="form-control" name="zakazchik" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="title" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Наименование закупки')); ?></label>

                            <div class="col-md-6">
                                <input id="title" type="text" value="<?php echo e($tender->title); ?>" class="form-control" name="title" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="quantity" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Количество (цифры)')); ?></label>

                            <div class="col-md-6">
                                <input id="quantity" type="number" value="<?php echo e($tender->quantity); ?>" class="form-control" name="quantity" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="priceForUnit" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Цена закупки за ед. (цифры)')); ?></label>

                            <div class="col-md-6">
                                <input id="priceForUnit" type="number" value="<?php echo e($tender->priceForUnit); ?>" class="form-control" name="priceForUnit" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="sum" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Сумма закупки (вычисляется автоматически)')); ?></label>

                            <div class="col-md-6">
                                <input id="sum" type="text" value="<?php echo e($tender->sum); ?>" class="form-control" name="sum" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="finishTime" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Срок окончания приема заявок')); ?></label>

                            <div class="col-md-6">
                                <input id="finishTime" type="text" value="<?php echo e($tender->finishTime); ?>" class="form-control" name="finishTime" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="address" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Адрес поставки')); ?></label>

                            <div class="col-md-6">
                                <input id="address" type="text" value="<?php echo e($tender->address); ?>" class="form-control" name="address" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="finishForDelivery" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Срок поставки (цифры)')); ?></label>

                            <div class="col-md-6">
                                <input id="finishForDelivery" type="text" value="<?php echo e($tender->finishForDelivery); ?>" class="form-control" name="finishForDelivery" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="obespechenie" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Обеспечение заявки')); ?></label>

                            <div class="col-md-6">
                                <input class="form-check-input" type="checkbox" <?php echo e($tender->obespechenie == "1" ? 'checked' : ''); ?> id="obespechenie" name="obespechenie">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="submitted" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Заявка подано')); ?></label>

                            <div class="col-md-6">
                                <input class="form-check-input" type="checkbox" <?php echo e($tender->submitted == "1" ? 'checked' : ''); ?> id="submitted" name="submitted">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="providerUnitPrice" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Цена поставщика за ед. (цифры)')); ?></label>

                            <div class="col-md-6">
                                <input id="providerUnitPrice" type="number" value="<?php echo e($tender->providerUnitPrice); ?>" class="form-control" name="providerUnitPrice" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="providerSumPrice" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Сумма поставщика (вычисляется автоматически)')); ?></label>

                            <div class="col-md-6">
                                <input id="providerSumPrice" type="number" class="form-control" value="<?php echo e($tender->providerSumPrice); ?>" name="providerSumPrice" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="transportation" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Транспортные расходы (цифры)')); ?></label>

                            <div class="col-md-6">
                                <input id="transportation" type="number" class="form-control" name="transportation" value="<?php echo e($tender->transportation); ?>" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="customs" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Растаможка (цифры)')); ?></label>

                            <div class="col-md-6">
                                <input id="customs" type="number" value="<?php echo e($tender->customs); ?>" class="form-control" name="customs" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="certification" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Сертификация (цифры)')); ?></label>

                            <div class="col-md-6">
                                <input id="certification" type="number" value="<?php echo e($tender->certification); ?>" class="form-control" name="certification" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="allConsumptions" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Общие расходы (вычисляется автоматически)')); ?></label>

                            <div class="col-md-6">
                                <input id="allConsumptions" type="number" value="<?php echo e($tender->allConsumptions); ?>" class="form-control" name="allConsumptions" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="myUnitPrice" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Моя цена за ед. (цифры)')); ?></label>

                            <div class="col-md-6">
                                <input id="myUnitPrice" type="number" value="<?php echo e($tender->myUnitPrice); ?>" class="form-control" name="myUnitPrice" required>
                            </div>
                        </div>
                         <div class="form-group row">
                            <label for="mySum" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Моя сумма (вычисляется автоматически)')); ?></label>

                            <div class="col-md-6">
                                <input id="mySum" type="number" value="<?php echo e($tender->mySum); ?>" class="form-control" name="mySum" required>
                            </div>
                        </div>
                         <div class="form-group row">
                            <label for="taxProcent" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Процент налогообложения Налог (вычисляется автоматически)')); ?></label>

                            <div class="col-md-6">
                                <input id="taxProcent" type="number" value="<?php echo e($tender->taxProcent); ?>" class="form-control" name="taxProcent" required>
                            </div>
                        </div>
                         <div class="form-group row">
                            <label for="profit" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Прибыль (вычисляется автоматически)')); ?></label>

                            <div class="col-md-6">
                                <input id="profit" type="number" value="<?php echo e($tender->profit); ?>" class="form-control" name="profit" required>
                            </div>
                        </div>
                         <div class="form-group row">
                            <label for="margin" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Маржа(%) (вычисляется автоматически)')); ?></label>

                            <div class="col-md-6">
                                <input id="margin" type="text" value="<?php echo e($tender->margin); ?>" class="form-control" name="margin" required>
                            </div>
                        </div>
                         <div class="form-group row">
                            <label for="sumNDS" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Сумма НДС (вычисляется автоматически)')); ?></label>

                            <div class="col-md-6">
                                <input id="sumNDS" type="number" value="<?php echo e($tender->sumNDS); ?>" class="form-control" name="sumNDS" required>
                            </div>
                        </div>
                         <div class="form-group row">
                            <label for="comission" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Комиссия банка за перевод и другие операции по тендеру (цифры)')); ?></label>

                            <div class="col-md-6">
                                <input id="comission" type="number" value="<?php echo e($tender->comission); ?>" class="form-control" name="comission" required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="tz" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Техничечкое задание на закупку  ')); ?></label>

                            <div class="col-md-6">
                                <a href="<?php echo e(url(''.$tender->tz)); ?>" target="_blank"><?php echo e($tender->tz); ?></a>
                                <input id="tz" type="file" class="form-control " name="tz" value="<?php echo e(old('tz')); ?>" autofocus>

                            </div>
                        </div>  

                        <div class="form-group row">
                            <label for="obespechenie" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Выиграли')); ?></label>

                            <div class="col-md-6">
                                <input id="won" class="form-check-input" type="checkbox" <?php echo e($tender->won == "1" ? 'checked' : ''); ?> id="won" name="won">
                            </div>
                        </div>

                        <div id="wonDiv" <?php echo e($tender->won != "1" ? "style='display: none'" : ''); ?> >
                            <div class="form-group row">
                                <label for="sumNDS" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Дата подписания договора ')); ?></label>

                                <div class="col-md-6">
                                    <input id="dogovorDate" type="text" value="<?php echo e($tender->dogovorDate); ?>" class="form-control" name="dogovorDate">
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="sumNDS" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Неустойка (вычисляется автоматически)')); ?></label>

                                <div class="col-md-6">
                                    <input id="neustoyka" type="text" value="<?php echo e($tender->neustoyka); ?>" class="form-control" name="neustoyka">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="sumNDS" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Контактное лицо заказчика (поле для заполнения)')); ?></label>

                                <div class="col-md-6">
                                    <input id="zakazchikLico" type="text" value="<?php echo e($tender->zakazchikLico); ?>" class="form-control" name="zakazchikLico">
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="sumNDS" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Контакты заказчика (поле для заполнения)')); ?></label>

                                <div class="col-md-6">
                                    <input id="zakazchikContact" type="text" value="<?php echo e($tender->zakazchikContact); ?>" class="form-control" name="zakazchikContact">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="obespechenie" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Получил оплату ')); ?></label>

                                <div class="col-md-6">
                                    <input class="form-check-input" type="checkbox" <?php echo e($tender->oplata == "1" ? 'checked' : ''); ?> id="oplata" name="oplata">
                                </div>
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Изменить')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
 $(document).ready(function(){
    $('#won').change(function(){
        if(this.checked)
            $('#wonDiv').fadeIn('slow');
        else
            $('#wonDiv').fadeOut('slow');

    });
});   
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tenderapp\resources\views/edittender.blade.php ENDPATH**/ ?>