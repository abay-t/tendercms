<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-9">
            <div class="card">
                <div class="card-header"><?php echo e(__('Изменить ползователя')); ?></div>
                <?php if(session()->has('message')): ?>
                <div class="alert alert-success">
                    <?php echo e(session()->get('message')); ?>

                </div>
                <?php endif; ?>
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('edituser', $user->id)); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('ФИО')); ?></label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name" value="<?php echo e($user->name); ?>" required autocomplete="name" autofocus>

                                <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('E-Mail Address')); ?></label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e($user->email); ?>" required autocomplete="email">

                                <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Password')); ?></label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" autocomplete="new-password">

                                <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password-confirm" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Confirm Password')); ?></label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" autocomplete="new-password">
                            </div>
                        </div>

                         <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Наименование организации')); ?></label>

                            <div class="col-md-6">
                                <input id="organization" type="text" class="form-control " name="organization" value="<?php echo e($user->organization); ?>"  autocomplete="organization" autofocus>

                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('БИН')); ?></label>

                            <div class="col-md-6">
                                <input id="bin" type="text" class="form-control " name="bin" value="<?php echo e($user->bin); ?>"  autocomplete="bin" autofocus>

                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Должность')); ?></label>

                            <div class="col-md-6">
                                <input id="dolzhnost" type="text" class="form-control " name="dolzhnost" value="<?php echo e($user->dolzhnost); ?>"  autocomplete="dolzhnost" autofocus>

                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Адрес')); ?></label>

                            <div class="col-md-6">
                                <input id="address" type="text" class="form-control " name="address" value="<?php echo e($user->address); ?>"  autocomplete="address" autofocus>

                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Контакты')); ?></label>

                            <div class="col-md-6">
                                <input id="contact" type="text" class="form-control " name="contact" value="<?php echo e($user->contact); ?>"  autocomplete="contact" autofocus>

                            </div>
                        </div>

                        

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Реквизиты ')); ?></label>

                            <div class="col-md-6">
                                <?php if(file_exists(getcwd().$user->rekvizit)){ ?>
                                    <?php echo e($user->rekvizit); ?>

                                <?php } ?>    
                                <input id="rekvizit" type="file" class="form-control " name="rekvizit" value="<?php echo e(old('rekvizit')); ?>"  autocomplete="rekvizit" autofocus>

                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Свидетельство о регистрации ')); ?></label>

                            <div class="col-md-6">
                                <?php if(file_exists(getcwd().$user->svidetelstvo)){ ?>
                                    <?php echo e($user->svidetelstvo); ?>

                                <?php } ?>
                                <input id="svidetelstvo" type="file" class="form-control " name="svidetelstvo" value="<?php echo e(old('svidetelstvo')); ?>"  autocomplete="svidetelstvo" autofocus>

                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Свидетельство о постановке на учет по НДС ')); ?></label>

                            <div class="col-md-6">
                                <?php if(file_exists(getcwd().$user->nds)){ ?>
                                    <?php echo e($user->nds); ?>

                                <?php } ?>
                                <input id="nds" type="file" class="form-control " name="nds" value="<?php echo e(old('nds')); ?>"  autocomplete="nds" autofocus>

                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Устав  ')); ?></label>

                            <div class="col-md-6">
                                <?php if(file_exists(getcwd().$user->ustav)){ ?>
                                    <?php echo e($user->ustav); ?>

                                <?php } ?>
                                <input id="ustav" type="file" class="form-control " name="ustav" value="<?php echo e(old('ustav')); ?>"  autocomplete="ustav" autofocus>

                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Приказ  ')); ?></label>

                            <div class="col-md-6">
                                <?php if(file_exists(getcwd().$user->prikaz)){ ?>
                                    <?php echo e($user->prikaz); ?>

                                <?php } ?>
                                <input id="prikaz" type="file" class="form-control " name="prikaz" value="<?php echo e(old('prikaz')); ?>"  autocomplete="prikaz" autofocus>

                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Решение ед. участника  ')); ?></label>

                            <div class="col-md-6">
                                <?php if(file_exists(getcwd().$user->reshenie)){ ?>
                                    <?php echo e($user->reshenie); ?>

                                <?php } ?>
                                <input id="reshenie" type="file" class="form-control " name="reshenie" value="<?php echo e(old('reshenie')); ?>" required autocomplete="reshenie" autofocus>

                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Изменить')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tenderapp\resources\views/admin/edituser.blade.php ENDPATH**/ ?>