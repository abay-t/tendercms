<?php $__env->startSection('content'); ?>
<div class="container">
        <div class="table-wrapper">
            <div class="table-title">
                <div class="row">
                    <div class="col-sm-5">
                        <a href="<?php echo e(url('admin/tenders')); ?>" class="btn btn-success">
                            <i class="fas fa-file-contract"></i> <span>Тендеры</span>
                        </a>
                    </div>
                    <div class="col-sm-7">
                        <a href="<?php echo e(route('addtender')); ?>" class="btn btn-primary"><i class="material-icons"></i> <span>Добавить тендер</span></a>
                        <!-- <a href="#" class="btn btn-primary"><i class="material-icons"></i> <span>Export to Excel</span></a> -->                       
                    </div>
                </div>
            </div>
            <?php if(session()->has('message')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('message')); ?>

            </div>
            <?php endif; ?>
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Наименование товара</th>                        
                        <th>Ссылка на тендер</th>
                        <th>Дата окончание</th>
                        <th>Статус</th>
                        <th>Действие</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $tenders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$tender): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                            <td><?php echo e(++$key); ?></td>
                            <td>
                                <a href="<?php echo e(url('tender/'.$tender->id)); ?>">
                                <?php echo e($tender->title); ?>

                                </a>
                            </td>
                            <td>
                                <a href="<?php echo e($tender->link); ?>" target="_blank"><?php echo e($tender->link); ?></a>
                            </td>                        
                            <td><?php echo e($tender->finishTime); ?></td>
                            <td><span class="status text-danger text-warning text-success">•</span> Active</td>
                            <td>
                                <a href="<?php echo e(url('tender/'.$tender->id.'/edit')); ?>" class="settings" title=""  data-original-title="Settings"><i class="material-icons"></i></a>
                                <a onclick="return confirm('Вы уверены?')"  href="<?php echo e(url('tender/'.$tender->id.'/delete')); ?>" class="delete" data-original-title="Delete"><i class="material-icons"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </tbody>
            </table>

            <?php echo $__env->make('pagination', ['paginator' => $tenders], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tenderapp\resources\views/home.blade.php ENDPATH**/ ?>