<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-9">
            <div class="card">
                <div class="card-header"><?php echo e(__('Добавить тендер')); ?></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('addtender')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="portal" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Портал закупки')); ?></label>

                            <div class="col-md-6">
                                <select name="portal" class="custom-select">
                                  <option selected>Выберите портала</option>
                                  <option value="Гос. закупки">Гос. закупки</option>
                                  <option value="Самурык">Самурык</option>
                                  <option value="Реестр">Реестр</option>
                                </select>

                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="type" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Тип закупки ')); ?></label>

                            <div class="col-md-6">
                                <select name="type" class="custom-select">
                                  <option selected>Выберите тип</option>
                                  <option value="Товар">Товар</option>
                                  <option value="Услуга">Услуга</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="predmet" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Предмет закупки')); ?></label>

                            <div class="col-md-6">
                                <select name="predmet" class="custom-select">
                                  <option selected>Выберите предмет</option>
                                  <option value="Товар">Товар</option>
                                  <option value="2">Предмет 2</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password-confirm" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Номер закупки')); ?></label>

                            <div class="col-md-6">
                                <input id="no" type="text" class="form-control" name="no" required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="link" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Ссылка на закупку')); ?></label>

                            <div class="col-md-6">
                                <input id="link" type="text" class="form-control" name="link" required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="zakazchik" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Заказчик')); ?></label>

                            <div class="col-md-6">
                                <input id="zakazchik" type="text" class="form-control" name="zakazchik" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="title" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Наименование закупки')); ?></label>

                            <div class="col-md-6">
                                <input id="title" type="text" class="form-control" name="title" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="quantity" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Количество (цифры)')); ?></label>

                            <div class="col-md-6">
                                <input id="quantity" type="number" class="form-control" name="quantity" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="priceForUnit" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Цена закупки за ед. (цифры)')); ?></label>

                            <div class="col-md-6">
                                <input id="priceForUnit" type="number" class="form-control" name="priceForUnit" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="sum" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Сумма закупки (вычисляется автоматически)')); ?></label>

                            <div class="col-md-6">
                                <input id="sum" type="text" class="form-control" name="sum" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="finishTime" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Срок окончания приема заявок')); ?></label>

                            <div class="col-md-6">
                                <input id="finishTime" type="text" class="form-control" name="finishTime" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="address" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Адрес поставки')); ?></label>

                            <div class="col-md-6">
                                <input id="address" type="text" class="form-control" name="address" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="finishForDelivery" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Срок поставки (цифры)')); ?></label>

                            <div class="col-md-6">
                                <input id="finishForDelivery" type="text" class="form-control" name="finishForDelivery" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="obespechenie" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Обеспечение заявки')); ?></label>

                            <div class="col-md-6">
                                <input class="form-check-input" type="checkbox" id="obespechenie" name="obespechenie">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="submitted" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Заявка подано')); ?></label>

                            <div class="col-md-6">
                                <input class="form-check-input" type="checkbox" id="submitted" name="submitted">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="providerUnitPrice" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Цена поставщика за ед. (цифры)')); ?></label>

                            <div class="col-md-6">
                                <input id="providerUnitPrice" type="number" class="form-control" name="providerUnitPrice" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="providerSumPrice" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Сумма поставщика (вычисляется автоматически)')); ?></label>

                            <div class="col-md-6">
                                <input id="providerSumPrice" type="number" class="form-control" name="providerSumPrice" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="transportation" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Транспортные расходы (цифры)')); ?></label>

                            <div class="col-md-6">
                                <input id="transportation" type="number" class="form-control" name="transportation" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="customs" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Растаможка (цифры)')); ?></label>

                            <div class="col-md-6">
                                <input id="customs" type="number" class="form-control" name="customs" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="certification" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Сертификация (цифры)')); ?></label>

                            <div class="col-md-6">
                                <input id="certification" type="number" class="form-control" name="certification" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="allConsumptions" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Общие расходы (вычисляется автоматически)')); ?></label>

                            <div class="col-md-6">
                                <input id="allConsumptions" type="number" class="form-control" name="allConsumptions" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="myUnitPrice" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Моя цена за ед. (цифры)')); ?></label>

                            <div class="col-md-6">
                                <input id="myUnitPrice" type="number" class="form-control" name="myUnitPrice" required>
                            </div>
                        </div>
                         <div class="form-group row">
                            <label for="mySum" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Моя сумма (вычисляется автоматически)')); ?></label>

                            <div class="col-md-6">
                                <input id="mySum" type="number" class="form-control" name="mySum" required>
                            </div>
                        </div>
                         <div class="form-group row">
                            <label for="taxProcent" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Процент налогообложения Налог (вычисляется автоматически)')); ?></label>

                            <div class="col-md-6">
                                <input id="taxProcent" type="number" class="form-control" name="taxProcent" required>
                            </div>
                        </div>
                         <div class="form-group row">
                            <label for="profit" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Прибыль (вычисляется автоматически)')); ?></label>

                            <div class="col-md-6">
                                <input id="profit" type="number" class="form-control" name="profit" required>
                            </div>
                        </div>
                         <div class="form-group row">
                            <label for="margin" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Маржа(%) (вычисляется автоматически)')); ?></label>

                            <div class="col-md-6">
                                <input id="margin" type="text" class="form-control" name="margin" required>
                            </div>
                        </div>
                         <div class="form-group row">
                            <label for="sumNDS" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Сумма НДС (вычисляется автоматически)')); ?></label>

                            <div class="col-md-6">
                                <input id="sumNDS" type="number" class="form-control" name="sumNDS" required>
                            </div>
                        </div>
                         <div class="form-group row">
                            <label for="comission" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Комиссия банка за перевод и другие операции по тендеру (цифры)')); ?></label>

                            <div class="col-md-6">
                                <input id="comission" type="number" class="form-control" name="comission" required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="tz" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Техничечкое задание на закупку  ')); ?></label>

                            <div class="col-md-6">
                                <input id="tz" type="file" class="form-control " name="tz" value="<?php echo e(old('tz')); ?>" required autofocus>

                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Добавить тендер')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tenderapp\resources\views/addtender.blade.php ENDPATH**/ ?>