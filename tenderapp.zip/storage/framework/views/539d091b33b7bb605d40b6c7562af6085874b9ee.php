<tr>
    <td class="header">
        <a href="<?php echo e($url); ?>">
            <?php echo e($slot); ?>

        </a>
    </td>
</tr>
<?php /**PATH C:\xampp\htdocs\tenderapp\vendor\laravel\framework\src\Illuminate\Mail/resources/views/html/header.blade.php ENDPATH**/ ?>