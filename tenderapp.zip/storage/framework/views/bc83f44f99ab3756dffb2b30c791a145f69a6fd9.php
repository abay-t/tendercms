<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-9">
            <div class="card">
                <div class="table-title">
                    <div class="row">
                        <div class="col-sm-5">
                            <a href="<?php echo e(url('admin/tenders')); ?>" class="btn btn-success">
                                <i class="fas fa-file-contract"></i> <span>Тендеры</span>
                            </a>
                        </div>
                        <div class="col-sm-7">
                            <a href="<?php echo e(route('addtender')); ?>" class="btn btn-primary"><i class="material-icons"></i> <span>Добавить тендер</span></a>
                            <!-- <a href="#" class="btn btn-primary"><i class="material-icons"></i> <span>Export to Excel</span></a> -->                       
                        </div>
                    </div>
                </div>
                <h2 style="padding: 15px;"><?php echo e(__('Данные о тендере')); ?></h2>
                <br>
                <?php if(session()->has('message')): ?>
                <div class="alert alert-success">
                    <?php echo e(session()->get('message')); ?>

                </div>
                <?php endif; ?>
                   

                        <div class="form-group row">
                            <label for="portal" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Портал закупки')); ?></label>

                            <div class="col-md-6">
                                <?php echo e($tender->portal); ?>


                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="type" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Тип закупки ')); ?></label>

                            <div class="col-md-6">
                                <?php echo e($tender->type); ?>

                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="predmet" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Предмет закупки')); ?></label>

                            <div class="col-md-6">
                                <?php echo e($tender->predmet); ?>

                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password-confirm" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Номер закупки')); ?></label>

                            <div class="col-md-6">
                                <?php echo e($tender->no); ?>

                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="link" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Ссылка на закупку')); ?></label>

                            <div class="col-md-6">
                                <?php echo e($tender->link); ?>

                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="zakazchik" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Заказчик')); ?></label>

                            <div class="col-md-6">
                                <?php echo e($tender->zakazchik); ?>

                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="title" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Наименование закупки')); ?></label>

                            <div class="col-md-6">
                                <?php echo e($tender->title); ?>

                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="quantity" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Количество (цифры)')); ?></label>

                            <div class="col-md-6">
                                <?php echo e($tender->quantity); ?>

                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="priceForUnit" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Цена закупки за ед. (цифры)')); ?></label>

                            <div class="col-md-6">
                                <?php echo e($tender->priceForUnit); ?>

                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="sum" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Сумма закупки (вычисляется автоматически)')); ?></label>

                            <div class="col-md-6">
                                <?php echo e($tender->sum); ?>

                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="finishTime" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Срок окончания приема заявок')); ?></label>

                            <div class="col-md-6">
                                <?php echo e($tender->finishTime); ?>

                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="address" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Адрес поставки')); ?></label>

                            <div class="col-md-6">
                                <?php echo e($tender->address); ?>

                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="finishForDelivery" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Срок поставки (цифры)')); ?></label>

                            <div class="col-md-6">
                                <?php echo e($tender->finishForDelivery); ?>

                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="obespechenie" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Обеспечение заявки')); ?></label>

                            <div class="col-md-6">
                                <input class="form-check-input" type="checkbox" <?php echo e($tender->obespechenie == "1" ? 'checked' : ''); ?> id="obespechenie" name="obespechenie">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="submitted" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Заявка подано')); ?></label>

                            <div class="col-md-6">
                                <input class="form-check-input" type="checkbox" <?php echo e($tender->submitted == "1" ? 'checked' : ''); ?> id="submitted" name="submitted">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="providerUnitPrice" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Цена поставщика за ед. (цифры)')); ?></label>

                            <div class="col-md-6">
                                <?php echo e($tender->providerUnitPrice); ?>

                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="providerSumPrice" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Сумма поставщика (вычисляется автоматически)')); ?></label>

                            <div class="col-md-6">
                                <?php echo e($tender->providerSumPrice); ?>

                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="transportation" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Транспортные расходы (цифры)')); ?></label>

                            <div class="col-md-6">
                                <?php echo e($tender->transportation); ?>

                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="customs" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Растаможка (цифры)')); ?></label>

                            <div class="col-md-6">
                                <?php echo e($tender->customs); ?>

                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="certification" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Сертификация (цифры)')); ?></label>

                            <div class="col-md-6">
                                <?php echo e($tender->certification); ?>

                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="allConsumptions" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Общие расходы (вычисляется автоматически)')); ?></label>

                            <div class="col-md-6">
                                <?php echo e($tender->allConsumptions); ?>

                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="myUnitPrice" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Моя цена за ед. (цифры)')); ?></label>

                            <div class="col-md-6">
                                <?php echo e($tender->myUnitPrice); ?>

                            </div>
                        </div>
                         <div class="form-group row">
                            <label for="mySum" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Моя сумма (вычисляется автоматически)')); ?></label>

                            <div class="col-md-6">
                                <?php echo e($tender->mySum); ?>

                            </div>
                        </div>
                         <div class="form-group row">
                            <label for="taxProcent" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Процент налогообложения Налог (вычисляется автоматически)')); ?></label>

                            <div class="col-md-6">
                                <?php echo e($tender->taxProcent); ?>

                            </div>
                        </div>
                         <div class="form-group row">
                            <label for="profit" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Прибыль (вычисляется автоматически)')); ?></label>

                            <div class="col-md-6">
                                <?php echo e($tender->profit); ?>

                            </div>
                        </div>
                         <div class="form-group row">
                            <label for="margin" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Маржа(%) (вычисляется автоматически)')); ?></label>

                            <div class="col-md-6">
                                <?php echo e($tender->margin); ?>

                            </div>
                        </div>
                         <div class="form-group row">
                            <label for="sumNDS" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Сумма НДС (вычисляется автоматически)')); ?></label>

                            <div class="col-md-6">
                                <?php echo e($tender->sumNDS); ?>

                            </div>
                        </div>
                         <div class="form-group row">
                            <label for="comission" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Комиссия банка за перевод и другие операции по тендеру (цифры)')); ?></label>

                            <div class="col-md-6">
                                <?php echo e($tender->comission); ?>

                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="tz" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Техничечкое задание на закупку  ')); ?></label>

                            <div class="col-md-6">
                                <a href="<?php echo e(url(''.$tender->tz)); ?>" target="_blank"><?php echo e($tender->tz); ?></a>
                                

                            </div>
                        </div>  

                        
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tenderapp\resources\views/showtender.blade.php ENDPATH**/ ?>